## PeerJS Documentation

We've moved! <a href="http://peerjs.com/docs">Check out our new
documentation.</a>

###[Browser compatibility and limitations](http://peerjs.com/status)

### [Discuss PeerJS on our Google Group](https://groups.google.com/forum/?fromgroups#!forum/peerjs)
